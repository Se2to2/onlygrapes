// ── PAGE BACKGROUND COLORS ──
const pageBg = {
  'index.html':    '#F7F0E2',
  'index':         '#F7F0E2',
  '':              '#F7F0E2',
  'devlog.html':   '#F7F0E2',
  'presskit.html': '#EDE3D4',
  'contact.html':  '#F7F0E2',
};

function getCurrentPage() {
  const path = window.location.pathname.toLowerCase();
  const file = path.split('/').pop() || '';
  return file;
}

function getBgForPage(href) {
  const file = href.toLowerCase().split('/').pop().split('#')[0] || '';
  return pageBg[file] || '#F7F0E2';
}

// ── TRANSITION OVERLAY ──
function createOverlay() {
  if (document.getElementById('page-transition')) return;
  const el = document.createElement('div');
  el.id = 'page-transition';
  document.body.appendChild(el);
}

function navigateTo(href) {
  const overlay = document.getElementById('page-transition');
  const targetBg = getBgForPage(href);

  // Set overlay color to the destination page's bg
  overlay.style.background = targetBg;

  // Exit: slide page content out
  const exitEls = document.querySelectorAll(
    '.section-content, .page-wrapper, .contact-wrapper, header.top-bar'
  );
  exitEls.forEach(el => el.classList.add('page-exit'));

  // After brief exit, wipe overlay in then navigate
  setTimeout(() => {
    overlay.classList.remove('wipe-out');
    overlay.classList.add('wipe-in');
    setTimeout(() => {
      window.location.href = href;
    }, 460);
  }, 220);
}

// ── PAGE ENTER ANIMATION ──
function runPageEnter() {
  const overlay = document.getElementById('page-transition');
  if (!overlay) return;

  const currentBg = getBgForPage(getCurrentPage());
  overlay.style.background = currentBg;

  // Start with overlay covering the page, then wipe it out
  overlay.style.transform = 'translateX(0%)';
  overlay.style.animation = 'none';

  // Slight delay so browser paints first
  requestAnimationFrame(() => {
    requestAnimationFrame(() => {
      overlay.classList.add('wipe-out');
    });
  });
}

// ── INTERCEPT INTERNAL LINKS ──
function attachTransitionLinks() {
  document.querySelectorAll('a').forEach(function (link) {
    const href = link.getAttribute('href');
    if (!href) return;

    // Skip anchors, external links, mailto, downloads
    if (href.startsWith('#') || href.startsWith('mailto') ||
        href.startsWith('http') || link.hasAttribute('download')) return;

    // Skip if already has listener
    if (link.dataset.transitionBound) return;
    link.dataset.transitionBound = 'true';

    link.addEventListener('click', function (e) {
      // If it's a cross-page link (not just an anchor on same page)
      const target = href.split('#')[0];
      const current = getCurrentPage();
      const targetClean = target.toLowerCase();

      if (target === '' || targetClean === current) {
        // Same page — just scroll, don't transition
        return;
      }

      e.preventDefault();
      navigateTo(href);
    });
  });
}

// ── CONTACT FORM ──
function handleSubmit() {
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const message = document.getElementById('message').value.trim();

  if (!name || !email || !message) {
    alert('Fill in at least your name, email, and a message.');
    return;
  }

  document.getElementById('contactForm').style.display = 'none';
  document.getElementById('successMsg').style.display = 'block';
}

// ── MAIN INIT ──
document.addEventListener('DOMContentLoaded', function () {
  createOverlay();
  runPageEnter();
  attachTransitionLinks();

  const sections = Array.from(document.querySelectorAll('.section'));
  const dots = Array.from(document.querySelectorAll('.dot'));

  // ── INDEX: scroll snap + fade ──
  if (sections.length > 0) {
    let isScrolling = false;

    function updateFades() {
      sections.forEach(function (section, i) {
        const rect = section.getBoundingClientRect();
        const middle = rect.top + rect.height / 2;
        const inView = middle > 0 && middle < window.innerHeight;
        const content = section.querySelector('.section-content');
        const dot = dots[i];
        if (content) content.style.opacity = inView ? 1 : 0;
        if (dot) dot.classList.toggle('active', inView);
      });
    }

    function scrollToSection(target) {
      if (isScrolling) return;
      isScrolling = true;
      const navHeight = 60;
      const targetTop = target.getBoundingClientRect().top + window.scrollY - navHeight;
      window.scrollTo({ top: targetTop, behavior: 'smooth' });
      setTimeout(() => { isScrolling = false; }, 1200);
    }

    // Anchor links (index internal)
    document.querySelectorAll('a[href^="#"]').forEach(function (link) {
      link.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) scrollToSection(target);
      });
    });

    window.addEventListener('scroll', updateFades);

    window.addEventListener('wheel', function (e) {
      e.preventDefault();
      if (isScrolling) return;
      isScrolling = true;

      const direction = e.deltaY > 0 ? 1 : -1;
      const current = sections.findIndex(s => {
        const middle = s.getBoundingClientRect().top + s.getBoundingClientRect().height / 2;
        return middle > 0 && middle < window.innerHeight;
      });
      const target = sections[Math.min(Math.max(current + direction, 0), sections.length - 1)];
      const navHeight = 60;
      const targetTop = target.getBoundingClientRect().top + window.scrollY - navHeight;
      window.scrollTo({ top: targetTop, behavior: 'smooth' });
      setTimeout(() => { isScrolling = false; }, 1200);
    }, { passive: false });

    updateFades();
  }

  // ── FAQ accordion ──
  document.querySelectorAll('.faq-question').forEach(function (btn) {
    btn.addEventListener('click', function () {
      const item = this.closest('.faq-item');
      const isOpen = item.classList.contains('open');
      document.querySelectorAll('.faq-item').forEach(el => {
        el.classList.remove('open');
        el.querySelector('.faq-question').setAttribute('aria-expanded', 'false');
      });
      if (!isOpen) {
        item.classList.add('open');
        this.setAttribute('aria-expanded', 'true');
      }
    });
  });

  // ── Dropdowns ──
  document.querySelectorAll('.dropdown-toggle').forEach(function (toggle) {
    toggle.addEventListener('click', function (e) {
      e.stopPropagation();
      const parent = this.closest('.dropdown');
      const isOpen = parent.classList.contains('open');
      document.querySelectorAll('.dropdown').forEach(d => d.classList.remove('open'));
      if (!isOpen) parent.classList.add('open');
    });
  });

  document.addEventListener('click', function (e) {
    if (!e.target.closest('.dropdown')) {
      document.querySelectorAll('.dropdown').forEach(d => d.classList.remove('open'));
    }
  });

  // ── SUB-PAGE fade-in (Netlify-safe) ──
  if (sections.length === 0) {
    const targets = document.querySelectorAll(
      '.page-wrapper > *, .contact-wrapper > *, .ct-form, .ct-field, ' +
      '.dl-post, .dl-filters, .pk-about, .pk-facts, .pk-fact, ' +
      '.pk-team-table, .pk-boilerplate, .pk-assets, .pk-contact-strip, ' +
      '.page-title, .page-label, .page-subtitle, .sub-label, .section-rule'
    );

    targets.forEach(function (el, i) {
      el.style.opacity = '0';
      el.style.transform = 'translateX(-20px)';
      el.style.transition = 'opacity 0.5s ease ' + (0.15 + i * 0.06) + 's, transform 0.5s ease ' + (0.15 + i * 0.06) + 's';
    });

    // Use a small delay so the wipe-out overlay clears first
    setTimeout(function () {
      targets.forEach(function (el) {
        el.style.opacity = '1';
        el.style.transform = 'translateX(0px)';
      });
    }, 300);
  }

  // ── Devlog inline functions (need global scope) ──
  window.filterPosts = function (tag, btn) {
    document.querySelectorAll('.dl-filter').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.dl-post').forEach(post => {
      post.style.display = (tag === 'all' || post.dataset.tag === tag) ? 'block' : 'none';
    });
  };

  window.togglePost = function (post) {
    const isExpanded = post.classList.contains('expanded');
    document.querySelectorAll('.dl-post.expanded').forEach(p => {
      p.classList.remove('expanded');
      p.querySelector('.dl-read-more').textContent = 'Read more →';
    });
    if (!isExpanded) {
      post.classList.add('expanded');
      post.querySelector('.dl-read-more').textContent = 'Collapse ↑';
    }
  };
});
